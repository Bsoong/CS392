//I pledge My honor that I have abided by the Stevens Honor System -Bsoong
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>

void cs392_SocketLogger(int add, int port);
