//I pledge my honor that I have abided by the Stevens Honor System. -Bsoong
#ifndef CS392_EXEC_H
#define CS392_EXEC_H
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>

void commandRun(char **ch);

#endif
