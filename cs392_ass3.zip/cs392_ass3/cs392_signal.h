//I pledge my honor that I have abided by the Stevens Honor System. -Bsoong
#ifndef CS392_SIGNAL_H
#define CS392_SIGNAL_H
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

void sigRegister();

#endif
