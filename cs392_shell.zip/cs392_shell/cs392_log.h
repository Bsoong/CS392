//I pledge my honor that I have abided by the Stevens Honor System. -Bsoong
#ifndef CS392_LOG_H
#define CS392_LOG_H
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

void appendToFile(char *ch);

#endif
