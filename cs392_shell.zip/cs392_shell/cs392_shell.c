//I pledge my honor that I have abided by the Stevens Honor System. -Bsoong
#include "cs392_signal.h"
#include "cs392_log.h"
#include "cs392_exec.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
  char ch[1024];
  while(1) {
    printf("cs392_shell $: ");
    fgets(ch, 20, stdin);
    appendToFile(ch);
    if(strcmp(ch, "exit") == 0)  {
      kill;
    }
  }
  return 1;
}
